const WHATSAPP = "50232707055";

function openWhatsApp(product) {
  const message = `Hola, HVentas. Estoy interesado en comprar: ${product}.`;
  const url = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank", "noopener,noreferrer");
}

document.querySelectorAll(".buy-btn[data-product]").forEach(button => {
  button.addEventListener("click", (event) => {
    event.preventDefault();
    openWhatsApp(button.dataset.product);
  });
});
