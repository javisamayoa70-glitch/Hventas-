HVentas — versión final integrada + Forminit

Se conserva el diseño del ZIP original y se agregan únicamente las funciones de pedidos.

FORMINIT
- Form ID: ky2srrl5fxn
- Los pedidos se envían directamente a Forminit.
- Campos enviados: ID del jugador, juego, producto, precio, método de pago, nombre opcional, fecha, estado y foto del comprobante.
- La foto se envía como archivo multipart/form-data.

PANEL ADMINISTRADOR
- Toca 3 veces el texto 𝐇𝐕entas de la parte superior izquierda.
- Ingresa la contraseña configurada en Netlify como HV_ADMIN_KEY.
- Los pedidos se consultan desde Forminit y se ordenan de mayor a menor precio.
- Se muestra el comprobante, ID del jugador y los datos del pedido.
- Estados disponibles: PENDIENTE, CONFIRMADO, NO VÁLIDO.

NETLIFY — VARIABLES DE ENTORNO
1. FORMINIT_API_KEY = tu API Token privado de Forminit.
2. HV_ADMIN_KEY = la contraseña que quieras usar para el panel.

No pongas FORMINIT_API_KEY dentro del HTML/JS ni la subas a GitHub.

AVISOS
Puedes activar una notificación por correo en Forminit para recibir un aviso cuando llegue un pedido. El panel también muestra los pedidos al actualizar.

IMPORTANTE SOBRE LOS ESTADOS
Los estados CONFIRMADO/NO VÁLIDO se guardan localmente en el dispositivo/navegador del administrador. Forminit no ofrece en esta integración un endpoint público para modificar el campo enviado de una entrega, por lo que no se presenta una falsa sincronización entre dispositivos.
