exports.handler = async (event) => {
  const providedKey = event.headers?.['x-hv-admin-key'] || event.headers?.['X-HV-ADMIN-KEY'] || '';
  const adminKey = process.env.HV_ADMIN_KEY || '';
  if (!adminKey || providedKey !== adminKey) return { statusCode: 401, body: JSON.stringify({error:'No autorizado'}) };
  const apiKey = process.env.FORMINIT_API_KEY || '';
  if (!apiKey) return { statusCode: 500, body: JSON.stringify({error:'Falta FORMINIT_API_KEY en Netlify'}) };
  const formId = 'ky2srrl5fxn';
  const url = `https://api.forminit.com/v1/forms/${formId}?page=1&size=100&files=true&timezone=America/Guatemala`;
  try {
    const r = await fetch(url, {headers:{'X-API-Key':apiKey,'Accept':'application/json'}});
    const body = await r.text();
    return {statusCode:r.status, headers:{'Content-Type':'application/json','Cache-Control':'no-store'}, body};
  } catch (e) { return {statusCode:502,body:JSON.stringify({error:'No se pudo consultar Forminit'})}; }
};
